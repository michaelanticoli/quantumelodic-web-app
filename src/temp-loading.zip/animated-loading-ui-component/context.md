# Loading UI Component

A premium animated loading component featuring a "Generating" text effect with vibrant, shifting radial gradients.

## Components

### LoadingUI

The core loading component that utilizes CSS masking and radial gradients to create a high-end "scanning" or "generating" visual effect.

#### Props

| Prop Name | Type | Default | Description |
|-----------|------|---------|-------------|
| className | string | '' | Additional classes for the wrapper element |
| ...props | object | {} | Standard HTML attributes |

#### Usage

```jsx
import LoadingUI from './ui/LoadingUI';

function LoadingState() {
  return (
    <div className="bg-black p-20 flex justify-center">
      <LoadingUI />
    </div>
  );
}
```

#### Visual Characteristics
- **Background**: Optimized for dark themes (`#0a0a0a` or `#000000`).
- **Animation**: 4s infinite loop for text, 2s alternating transform for the gradient glow.
- **Typography**: Uses "Poppins" (sans-serif) with a font weight of 600.
- **Color Palette**: Dynamic mix of Yellow (#ff0), Red (#f00), Cyan (#0ff), Green (#0f0), and Blue (#00f) within the animated mask.

#### Design Notes
- The component uses `mask-image` with `repeating-linear-gradient` to create the "scanline" vertical bars effect.
- The `::after` pseudo-element on the `.loader` div handles the complex multi-color radial gradient movement.
- Responsive by default via the `loader-wrapper` flex settings.