import React, { useState } from 'react';
import LoadingUI from './ui/LoadingUI';
import './App.css';

function App() {
  const [showExamples, setShowExamples] = useState(false);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white p-8 selection:bg-blue-500/30">
      {/* Toggle Button */}
      <button
        onClick={() => setShowExamples(!showExamples)}
        className="fixed top-6 right-6 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/10 px-6 py-2.5 rounded-full transition-all duration-300 font-medium z-50 shadow-2xl"
      >
        {showExamples ? 'View Primary' : 'View Examples'}
      </button>

      {!showExamples ? (
        // Primary instance
        <div className="flex flex-col items-center justify-center min-h-[80vh]">
          <div className="relative group">
            <div className="absolute -inset-20 bg-blue-500/5 rounded-full blur-3xl opacity-50 group-hover:opacity-100 transition-opacity duration-1000"></div>
            <LoadingUI />
          </div>
        </div>
      ) : (
        // Examples section
        <div className="max-w-5xl mx-auto pt-12 pb-24 space-y-16">
          <header className="text-center space-y-4">
            <h1 className="text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-b from-white to-white/50">
              Component Variations
            </h1>
            <p className="text-neutral-500 max-w-lg mx-auto">
              Visualizing the loading state across different container contexts and scales.
            </p>
          </header>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Standard Container */}
            <div className="group relative bg-[#111] border border-white/5 rounded-3xl p-12 overflow-hidden transition-all hover:border-white/10">
              <div className="absolute top-4 left-6 text-xs font-mono text-neutral-600 uppercase tracking-widest">Standard Canvas</div>
              <div className="flex items-center justify-center pt-8">
                <LoadingUI />
              </div>
            </div>

            {/* In-Card Variation */}
            <div className="group relative bg-gradient-to-br from-blue-600/10 to-purple-600/10 border border-blue-500/10 rounded-3xl p-12 overflow-hidden transition-all hover:border-blue-500/20">
              <div className="absolute top-4 left-6 text-xs font-mono text-blue-400/60 uppercase tracking-widest">Accent Canvas</div>
              <div className="flex items-center justify-center pt-8">
                <LoadingUI />
              </div>
            </div>

            {/* Dark Deep Variation */}
            <div className="group relative bg-black border border-white/5 rounded-3xl p-12 overflow-hidden transition-all hover:border-white/10 md:col-span-2">
              <div className="absolute top-4 left-6 text-xs font-mono text-neutral-700 uppercase tracking-widest">Deep Space</div>
              <div className="flex items-center justify-center pt-12 pb-4">
                <LoadingUI />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;